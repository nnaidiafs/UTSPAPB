package com.example.utspapb_20104410011

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
