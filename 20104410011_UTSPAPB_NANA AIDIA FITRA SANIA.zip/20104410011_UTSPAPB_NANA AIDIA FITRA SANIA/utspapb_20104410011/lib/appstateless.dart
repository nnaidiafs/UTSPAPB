import 'package:flutter/material.dart';

class AppStateless extends StatelessWidget {
  const AppStateless({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contoh Stateless',
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text('Stateless Widget'),
        ),
        body: Center(
          child: Text('Angka: 27', style: TextStyle(fontSize: 30)),
        ),
      ),
    );
  }
}