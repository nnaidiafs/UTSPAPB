import 'package:flutter/material.dart';

class AppStatefull extends StatefulWidget {
  const AppStatefull({super.key});

  @override
  State<AppStatefull> createState() => _AppStatefullState();
}

class _AppStatefullState extends State<AppStatefull> {
  int angka = 0;

  void ContohIncrement(){
    setState(() {
      angka +=3;
    });
  }
@override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UTS PAPB',
      home: Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () => ContohIncrement(),
          child: Icon(Icons.add),
        ),
        appBar: AppBar(
          centerTitle: true,
          title: Text('NANA AIDIA FITRA SANIA - NOMOR GANJIL'),
        ),
        body: Center(
          child: Text('Bilangan Kelipatan 3 Adalah : $angka', style: TextStyle(fontSize: 30)),
        ),
      ),
    );
  }
}